-- ============================================================
-- MAILING MICROSERVICE - FULL DATABASE SCHEMA
-- Run this to create the mailing_db database and all tables
-- ============================================================

CREATE DATABASE IF NOT EXISTS mailing_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mailing_db;

-- ------------------------------------------------------------
-- 1. SETTINGS
-- Stores all toggle switches, SMTP overrides, and config values
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS mail_settings (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Default toggle values (all major triggers pre-seeded as OFF)
INSERT INTO mail_settings (setting_key, setting_value) VALUES
    ('notify_customer_signup',        '0'),
    ('notify_customer_login',         '0'),
    ('notify_customer_pwd_reset',     '0'),
    ('notify_customer_order_receipt', '0'),
    ('notify_customer_order_status',  '0'),
    ('notify_vendor_new_order',       '0'),
    ('notify_vendor_low_stock',       '0'),
    ('notify_hq_new_vendor',          '0'),
    ('notify_hq_admin_login',         '0')
ON DUPLICATE KEY UPDATE setting_key = setting_key;


-- ------------------------------------------------------------
-- 2. TEMPLATES
-- Stores designed email templates from the template builder UI
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS mail_templates (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    template_name       VARCHAR(150) NOT NULL,
    email_bg_color      VARCHAR(20)  DEFAULT '#f8faf9',
    email_card_bg       VARCHAR(20)  DEFAULT '#ffffff',
    email_body_text     VARCHAR(20)  DEFAULT '#1a1a1a',
    email_link_color    VARCHAR(20)  DEFAULT '#2563eb',
    email_header_text   VARCHAR(200) DEFAULT '',
    email_header_font   VARCHAR(100) DEFAULT 'Arial, sans-serif',
    email_header_raw    TEXT,
    email_header_img    VARCHAR(255) DEFAULT '',
    email_footer_bg     VARCHAR(20)  DEFAULT '#f3f4f6',
    email_footer_text   VARCHAR(20)  DEFAULT '#6b7280',
    email_footer_raw    TEXT,
    email_footer_img    VARCHAR(255) DEFAULT '',
    created_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed a default fallback template
INSERT INTO mail_templates (template_name, email_header_text, email_bg_color, email_card_bg)
VALUES ('Default Template', 'System Notification', '#f8faf9', '#ffffff');


-- ------------------------------------------------------------
-- 3. SUBSCRIBERS
-- External newsletter subscribers (not registered app users)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS mail_subscribers (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    email           VARCHAR(255) NOT NULL UNIQUE,
    status          ENUM('active', 'unsubscribed') DEFAULT 'active',
    subscribed_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- ------------------------------------------------------------
-- 4. CAMPAIGNS
-- Logs every manual broadcast sent from the Compose page
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS mail_campaigns (
    id               INT AUTO_INCREMENT PRIMARY KEY,
    subject          VARCHAR(255) NOT NULL,
    theme            VARCHAR(100) DEFAULT 'custom',
    audience         VARCHAR(50)  DEFAULT 'all',
    recipients_count INT          DEFAULT 0,
    sent_at          TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);


-- ------------------------------------------------------------
-- 5. EMAIL HISTORY
-- Logs every single email sent — broadcasts AND event triggers
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS email_history (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    app_source      VARCHAR(100) DEFAULT 'system',
    recipient_email VARCHAR(255) NOT NULL,
    subject         VARCHAR(255),
    event_name      VARCHAR(100) DEFAULT NULL,  -- NULL for manual broadcasts
    status          ENUM('sent', 'failed') DEFAULT 'failed',
    error_message   TEXT,
    sent_at         TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_app_source  (app_source),
    INDEX idx_event_name  (event_name),
    INDEX idx_status      (status),
    INDEX idx_sent_at     (sent_at)
);


-- ------------------------------------------------------------
-- 6. EVENT MAPPINGS  ← The zero-code connection layer
-- Each row = one event from one app mapped to one email config
-- Adding a new app = adding rows here via the UI, no PHP needed
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS mail_event_mappings (
    id               INT AUTO_INCREMENT PRIMARY KEY,

    -- Which app fires this event (e.g. 'cakes', 'scrummy', 'any')
    -- Use 'any' to match all apps firing the same event name
    app_source       VARCHAR(100) NOT NULL DEFAULT 'any',

    -- The event name fired by the app (e.g. 'order.placed')
    event_name       VARCHAR(100) NOT NULL,

    -- Human-readable label shown in the UI
    display_name     VARCHAR(150) NOT NULL DEFAULT '',

    -- Which template to wrap the email body in
    template_id      INT NOT NULL DEFAULT 1,

    -- Subject line — supports {{placeholders}} from the data payload
    -- e.g. "Your Order #{{order_id}} is Confirmed!"
    subject_template VARCHAR(255) NOT NULL,

    -- Which key in the incoming data payload holds the recipient email
    -- e.g. 'customer_email' or 'admin_email'
    recipient_field  VARCHAR(100) NOT NULL DEFAULT 'customer_email',

    -- The email body — supports {{placeholders}}
    -- Written once here, reused every time this event fires
    body_template    TEXT,

    -- Toggle: is this mapping active?
    is_active        TINYINT(1) DEFAULT 1,

    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    -- Prevent duplicate mappings for same app+event combo
    UNIQUE KEY unique_app_event (app_source, event_name),

    INDEX idx_event_name (event_name),
    INDEX idx_app_source (app_source),
    INDEX idx_is_active  (is_active)
);


-- ------------------------------------------------------------
-- SEED: Default event mappings for scrummy + cakes
-- These match the toggle keys already in mail_settings
-- You can edit subject/body from the UI after setup
-- ------------------------------------------------------------
INSERT INTO mail_event_mappings
    (app_source, event_name, display_name, template_id, subject_template, recipient_field, body_template, is_active)
VALUES

-- SCRUMMY
('scrummy', 'user.registered', 'Scrummy: New User Welcome', 1,
 'Welcome to {{site_name}}, {{customer_name}}!',
 'customer_email',
 '<h2>Welcome, {{customer_name}}!</h2><p>Your account has been created successfully on <strong>{{site_name}}</strong>.</p><p>You can now browse our menu and place orders.</p>',
 0),

('scrummy', 'order.placed', 'Scrummy: Order Confirmation', 1,
 'Order #{{order_id}} Confirmed – {{site_name}}',
 'customer_email',
 '<h2>Order Confirmed! 🎉</h2><p>Hi {{customer_name}}, your order has been received.</p><table style="width:100%;border-collapse:collapse;"><tr><td><strong>Order ID</strong></td><td>#{{order_id}}</td></tr><tr><td><strong>Total</strong></td><td>₦{{total_amount}}</td></tr><tr><td><strong>Payment</strong></td><td>{{payment_method}}</td></tr><tr><td><strong>Address</strong></td><td>{{delivery_address}}</td></tr></table><p>We will notify you when your order is on its way.</p>',
 0),

('scrummy', 'order.status_changed', 'Scrummy: Order Status Update', 1,
 'Your Order #{{order_id}} is now: {{new_status}}',
 'customer_email',
 '<h2>Order Update</h2><p>Hi {{customer_name}}, your order <strong>#{{order_id}}</strong> status has been updated to: <strong>{{new_status}}</strong>.</p>',
 0),

-- CAKES
('cakes', 'user.registered', 'Cakes: New User Welcome', 1,
 'Welcome to {{site_name}}, {{customer_name}}!',
 'customer_email',
 '<h2>Welcome, {{customer_name}}!</h2><p>Your account has been created successfully on <strong>{{site_name}}</strong>.</p><p>You can now browse our menu and place orders.</p>',
 0),

('cakes', 'order.placed', 'Cakes: Order Confirmation', 1,
 'Order #{{order_id}} Confirmed – {{site_name}}',
 'customer_email',
 '<h2>Order Confirmed! 🎉</h2><p>Hi {{customer_name}}, your order has been received.</p><table style="width:100%;border-collapse:collapse;"><tr><td><strong>Order ID</strong></td><td>#{{order_id}}</td></tr><tr><td><strong>Total</strong></td><td>₦{{total_amount}}</td></tr><tr><td><strong>Payment</strong></td><td>{{payment_method}}</td></tr><tr><td><strong>Address</strong></td><td>{{delivery_address}}</td></tr></table><p>We will notify you when your order is on its way.</p>',
 0),

('cakes', 'order.status_changed', 'Cakes: Order Status Update', 1,
 'Your Order #{{order_id}} is now: {{new_status}}',
 'customer_email',
 '<h2>Order Update</h2><p>Hi {{customer_name}}, your order <strong>#{{order_id}}</strong> status has been updated to: <strong>{{new_status}}</strong>.</p>',
 0),

-- SYSTEM-WIDE (app_source = 'any' matches any app firing this event)
('any', 'admin.login', 'System: Admin Login Alert', 1,
 'Security Alert: New Admin Login on {{app_name}}',
 'admin_email',
 '<h2>Admin Login Detected</h2><p>A new login was recorded on <strong>{{app_name}}</strong>.</p><table style="width:100%;border-collapse:collapse;"><tr><td><strong>Admin</strong></td><td>{{admin_name}}</td></tr><tr><td><strong>Time</strong></td><td>{{login_time}}</td></tr><tr><td><strong>IP Address</strong></td><td>{{ip_address}}</td></tr></table><p>If this was not you, please change your password immediately.</p>',
 0)

ON DUPLICATE KEY UPDATE event_name = event_name;
